import argparse
import logging

import mlflow
import src.ingest_data as ingest_data
import src.score as score
import src.train as train

if __name__ == "__main__":
    # Parse command line arguments
    parser = argparse.ArgumentParser(
        description=("Download and create training" + "and test datasets.")
    )
    # Arguments for ingest_data
    parser.add_argument(
        "--dl_data_dir", type=str, default="data/raw", help="output folder/file path"
    )

    # Arguments for train
    parser.add_argument(
        "--inp_train_dir",
        type=str,
        default="data/raw",
        help="Input folder containing the train set",
    )
    parser.add_argument(
        "--train_pkl_dir",
        type=str,
        default="artifacts/model_pickle_files",
        help="Output folder to save the model pickle",
    )
    parser.add_argument(
        "--train_score_dir",
        type=str,
        default="data/prediction_scores/train",
        help="Output folder to save the model scores",
    )

    # Arguments for score
    parser.add_argument(
        "--test_pkl_dir",
        type=str,
        default="artifacts/model_pickle_files",
        help="path to directory containing model pickle files",
    )
    parser.add_argument(
        "--inp_test_dir",
        type=str,
        default="data/raw",
        help="path to directory containing test data",
    )
    parser.add_argument(
        "--test_score_dir",
        type=str,
        default="data/prediction_scores/test",
        help="path to output directory",
    )

    # Arguments for generating logs
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Set the log level (default: INFO)",
    )
    parser.add_argument("--log-path", help="Set the path of the log file (default: no log file)")
    parser.add_argument(
        "--no-console-log",
        action="store_true",
        help="Disable writing logs to console (default: logs are written to console)",
    )
    args = parser.parse_args()

    if args.log_path:
        logging.basicConfig(
            filename=args.log_path,
            level=args.log_level,
            format="%(asctime)s - %(levelname)s - %(message)s",
        )

    # Always enable console logging unless specified otherwise
    if not args.no_console_log:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(args.log_level)
        console_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        console_handler.setFormatter(console_formatter)
        console_logger = logging.getLogger()
        console_logger.addHandler(console_handler)
        console_logger.setLevel(args.log_level)

    # Set the MLflow experiment
    mlflow.set_experiment("Housing Regression")

    with mlflow.start_run(run_name="main") as main_run:
        # Define the paths to the output directories and files
        dl_data_dir = args.dl_data_dir
        train_set_dir = args.inp_train_dir
        train_pkl_dir = args.train_pkl_dir
        train_score_dir = args.train_score_dir
        test_pkl_dir = args.test_pkl_dir
        test_set_dir = args.inp_test_dir
        test_score_dir = args.test_score_dir

        # Run data ingestion script
        with mlflow.start_run(run_name="data_ingestion", nested=True):
            # Log parameters and tags for the run
            data_url = ingest_data.data_url
            mlflow.log_param("data_url", data_url)
            mlflow.log_param("download_data_dir", dl_data_dir)

            # Run the data ingestion script
            ingest_data.download_dataset(data_url, dl_data_dir)
            ingest_data.create_train_test_split(dl_data_dir, data_url)

        # Train the model
        with mlflow.start_run(run_name="model_training", nested=True):
            # Log parameters and tags for the run
            mlflow.log_param("train_set_input_dir", train_set_dir)
            mlflow.log_param("pkl_output_dir", train_pkl_dir)
            mlflow.log_param("train_score_output_dir", train_score_dir)

            # Train the model
            train.train_model(train_set_dir, train_pkl_dir, train_score_dir)

        # Evaluate the model on the test set and log the performance metrics
        with mlflow.start_run(run_name="model_evaluation", nested=True):
            # Log parameters and tags for the run
            mlflow.log_param("test_set_dir", test_set_dir)
            mlflow.log_param("test_pkl_dir", test_pkl_dir)
            mlflow.log_param("test_score_dir", test_score_dir)

            models = score.load_models(test_pkl_dir)
            strat_test_set = score.load_test_data(test_set_dir)
            # Evaluate the model
            score.score_models(models, strat_test_set, test_score_dir)

    # Log final message
    logging.info("Done!")
