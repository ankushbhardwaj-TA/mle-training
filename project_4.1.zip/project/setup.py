from setuptools import setup

setup(
    setup_cfg=True,
)
