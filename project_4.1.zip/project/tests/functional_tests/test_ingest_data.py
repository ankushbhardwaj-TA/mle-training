# tests/functional_tests/test_ingest_data.py

import os

import pandas as pd
from src.ingest_data import download_dataset, load_housing_data

data_url = ("https://raw.githubusercontent.com/ageron/handson-ml/master" +
            "/datasets/housing/housing.csv")   # URL to download dataset


def test_download_and_load_housing_data(tmp_path):
    # Download and save the data to a temporary directory
    output_dir = tmp_path / "data"
    download_dataset(data_url, output_dir)
    assert os.path.exists(output_dir / "data.csv")

    # Load the data from the downloaded file
    housing = load_housing_data(output_dir / "data.csv")
    assert isinstance(housing, pd.DataFrame)
    assert len(housing) > 0
    assert set(housing.columns) == set(['longitude', 'latitude', 'housing_median_age',
                                        'total_rooms', 'total_bedrooms', 'population',
                                        'households', 'median_income', 'median_house_value',
                                        'ocean_proximity'])
